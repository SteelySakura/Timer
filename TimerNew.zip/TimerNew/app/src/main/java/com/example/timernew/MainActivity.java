package com.example.timernew;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private long timeLeftInMillis;
    private long pauseOffsetInMillis;
    private boolean isRunning = false;
    private boolean isPaused = false;
    private TextView timerTextView;
    private EditText timeEditText;
    private MediaPlayer mediaPlayer;
    private CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timerTextView = findViewById(R.id.timerTextView);
        timeEditText = findViewById(R.id.timeEditText);
        mediaPlayer = MediaPlayer.create(this, R.raw.time_over);

        ImageButton historyButton = findViewById(R.id.historyButton);
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TimerHistoryActivity.class);
                startActivity(intent);
            }
        });
    }

    public void startTimer(View view) {
        if (isRunning) {
            // Таймер уже запущен, нет необходимости второй раз
            return;
        }

        String timeString = timeEditText.getText().toString();
        if (timeString.isEmpty()) {
            // Проверка на пустой ввод
            Toast.makeText(this, "Введите время", Toast.LENGTH_SHORT).show();
            return;
        }

        long setTimeInMillis;
        try {
            int time = Integer.parseInt(timeString);
            if (time <= 0) {
                // Проверка на недопустимое значение времени
                Toast.makeText(this, "Введите положительное значение времени", Toast.LENGTH_SHORT).show();
                return;
            }
            setTimeInMillis = time * 1000;
        } catch (NumberFormatException e) {
            // Проверка на некорректный формат ввода
            Toast.makeText(this, "Введите корректное значение времени", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isPaused) {
            timeLeftInMillis = pauseOffsetInMillis;
            isPaused = false;
        } else {
            timeLeftInMillis = setTimeInMillis;
            //Записываем время в БД
            TimerHistoryActivity.TimerDatabaseHelper dbHelper = new TimerHistoryActivity.TimerDatabaseHelper(this);
            dbHelper.insertTimer(timeLeftInMillis);
        }

        isRunning = true;

        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            private long startTimeInMillis;

            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;

                long elapsedTimeInMillis = System.currentTimeMillis() - startTimeInMillis;
                long timeLeftPlusDelayInMillis = timeLeftInMillis + 1000;
                long timeLeftPlusDelayAndElapsedTimeInMillis = timeLeftPlusDelayInMillis + elapsedTimeInMillis;

                if (timeLeftPlusDelayAndElapsedTimeInMillis <= 0) {
                    timeLeftInMillis = 0;
                    onFinish();
                } else {
                    updateTimerText();
                }
            }

            @Override
            public void onFinish() {
                isRunning = false;
                mediaPlayer.start();
                updateTimerText();
            }
        }.start();
    }

    public void pauseTimer(View view) {
        if (!isRunning) {
            // Таймер уже остановлен
            return;
        }

        countDownTimer.cancel();
        pauseOffsetInMillis = timeLeftInMillis;
        isPaused = true;
        isRunning = false;
    }

    public void resetTimer(View view) {
        if (isRunning || isPaused) {
            countDownTimer.cancel();
            isRunning = false;
            isPaused = false;
        }

        timeLeftInMillis = 0;
        pauseOffsetInMillis = 0;
        updateTimerText();
        mediaPlayer.stop();
        mediaPlayer.prepareAsync();
    }

    private void updateTimerText() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                timerTextView.setText(String.format("%02d:%02d", minutes, seconds));
            }
        });
    }

    public void setTime(View view) {
        Intent intent = new Intent(this, SetTimeActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            String timeString = data.getStringExtra("time");
            if (timeString != null) {
                timeEditText.setText(timeString);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.release();
    }
}