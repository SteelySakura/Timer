package com.example.timernew;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class TimerHistoryActivity extends AppCompatActivity {
    private ListView timerHistoryListView;
    private TimerDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_history);

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        timerHistoryListView = findViewById(R.id.timerHistoryListView);
        dbHelper = new TimerDatabaseHelper(this);

        Cursor cursor = dbHelper.getAllTimers();
        String[] fromColumns = {"time"};
        int[] toViews = {android.R.id.text1};
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1, cursor, fromColumns, toViews, 0);
        timerHistoryListView.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbHelper.close();
    }

    public static class TimerDatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "timer_history.db";
        private static final int DATABASE_VERSION = 1;

        public TimerDatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE timer_history (_id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER);");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // ...
        }

        public void insertTimer(long timeInMillis) {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("time", timeInMillis/1000);
            db.insert("timer_history", null, values);
            db.close();
        }

        public Cursor getAllTimers() {
            SQLiteDatabase db = getReadableDatabase();
            return db.rawQuery("SELECT * FROM timer_history", null);
        }
    }
}


