package com.example.timernew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SetTimeActivity extends AppCompatActivity {

    private EditText timeEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_time);

        timeEditText = findViewById(R.id.timeEditText);

        Button cancelButton = findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void setTime(View view) {
        String timeString = timeEditText.getText().toString();
        Intent intent = new Intent();
        intent.putExtra("time", timeString);
        setResult(RESULT_OK, intent);
        finish();
    }
}
